# OSS Project Management

Name: <fill-this-with-your-name>
<br>
City: <fill-this-with-your-city>

## Getting Started

This project aims to automate deployment for the [Leantime](https://docs.leantime.io/) application and the [Gatus](https://github.com/TwiN/gatus?tab=readme-ov-file) application. To get started, please follow these steps:

1. **Fork this repository**.
2. **Clone the forked repository**.
3. **Configure the applications**.
4. **Create Workflow Files**.
